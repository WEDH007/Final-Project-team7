package com.bookstore.browsing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrowsingApplicationTests {

	@Test
	void contextLoads() {
	}

}
